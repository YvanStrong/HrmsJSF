package rw.auca.hrms.utilites;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import rw.auca.hrms.entities.Employee;

public class EmployeeDao {
    public void create(Employee e){
        Session ss = HibernateUtility.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.save(e);
        ss.getTransaction().commit();
        ss.close();
    }
    
    public void payEmployees(List<Employee> list){
        Session ss = HibernateUtility.getSessionFactory().openSession();
        ss.beginTransaction();
        for(Employee e: list){
            ss.save(e);
        }
        ss.getTransaction().commit();
        ss.close();
    }
    public void update(Employee e){
        Session ss = HibernateUtility.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.update(e);
        ss.getTransaction().commit();
        ss.close();
    }
    
    public void delete(Employee e){
        Session ss = HibernateUtility.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.delete(e);
        ss.getTransaction().commit();
        ss.close();
    }
    
    public Employee readOne(String empId){
        Session ss = HibernateUtility.getSessionFactory().openSession();
        Employee e = (Employee)ss.get(Employee.class, empId);
        ss.close();
        return e;
    }
    
    public List<Employee> readAll(){
        Session ss = HibernateUtility.getSessionFactory().openSession();
        Query qry = ss.createQuery("from Employee");
        List<Employee> list = qry.list();
        ss.close();
        return list;
    }
}
