/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rw.auca.hrms.model;

import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import rw.auca.hrms.entities.Employee;
import rw.auca.hrms.utilites.EmployeeDao;

@ManagedBean(name = "empCrud")
public class EmployeeCRUD {
    private Employee employee = new Employee();
    //private List<Employee> empList = new ArrayList<>();
    EmployeeDao empDao = new EmployeeDao();
    private String action = "Create";
    public String execute(){
        try{   
            if(action.equals("Create")){
                empDao.create(employee);
            }else if(action.equals("Update")){
                empDao.update(employee);
            }
            
            FacesMessage msg = new FacesMessage("Employee created successfully");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            return "employeeList";
        }catch(Exception ex){
            FacesMessage msg = new FacesMessage("Failed to create employee: "+ex.getMessage());
            FacesContext.getCurrentInstance().addMessage(null, msg);
            return "employeeForm";
        }
    }
    
    public String update(Employee emp){
        this.employee = emp;
        this.action = "Update";
        return "employeeForm";
    }

    public Employee getEmployee() {
        return employee;
    }

    public List<Employee> getEmpList() {
        return empDao.readAll();
    }

    public EmployeeDao getEmpDao() {
        return empDao;
    }

    public void setEmpDao(EmployeeDao empDao) {
        this.empDao = empDao;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

   
    
}
